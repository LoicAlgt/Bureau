# Firewall rules
Retrieve all firewall rules